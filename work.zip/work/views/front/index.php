<?php



/* 
 * Stripe API configuration 
 * Remember to switch to your live publishable and secret key in production! 
 * See your keys here: https://dashboard.stripe.com/account/apikeys 
 */
define('STRIPE_API_KEY', 'sk_test_51K2ypjFCUv1zW2i1sIeBNORCye0Sm3t3OgoVx5ISIRNy9hzAFcxLOMPCMEpc7LZbhOIIl1v8i1Xd63uNOPu137IL00dztgPR7T');
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51K2ypjFCUv1zW2i1rr3TKnPNmE5565ZEnnyPdDktCvSez4bxhnFys9NXi5yeRkTHSuGR4H2u8ob4GuQ9lbU0MGcm00mNLXctbR');
define('STRIPE_SUCCESS_URL', 'http://localhost:7882/work/views/front/payment-success.php'); //Payment success URL 
define('STRIPE_CANCEL_URL', 'http://localhost:7882/work/views/front/payment-cancel.php'); //Payment cancel URL 

// Database configuration    
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'productdb');

?>

<?php
session_start();
$database_name = "Productdb";
$con = mysqli_connect("localhost", "root", "", $database_name);
if (isset($_POST["add"])) {
    if (isset($_SESSION["cart"])) {
        $item_array_id = array_column($_SESSION["cart"], "product_id");
        if (!in_array($_GET["id"], $item_array_id)) {
            $count = count($_SESSION["cart"]);
            $item_array = array(
                'product_id' => $_GET["id"],
                'item_name' => $_POST["hidden_name"],
                'product_price' => $_POST["hidden_price"],
                'item_quantity' => $_POST["quantity"],
            );
            $_SESSION["cart"][$count] = $item_array;
            echo '<script>window.location="index.php"</script>';
        } else {
            echo '<script>alert("Product is already Added to Cart")</script>';
            echo '<script>window.location="index.php"</script>';
        }
    } else {
        $item_array = array(
            'product_id' => $_GET["id"],
            'item_name' => $_POST["hidden_name"],
            'product_price' => $_POST["hidden_price"],
            'item_quantity' => $_POST["quantity"],
        );
        $_SESSION["cart"][0] = $item_array;
    }
}

if (isset($_GET["action"])) {
    if ($_GET["action"] == "delete") {
        foreach ($_SESSION["cart"] as $keys => $value) {
            if ($value["product_id"] == $_GET["id"]) {
                unset($_SESSION["cart"][$keys]);
                echo '<script>alert("Product has been Removed...!")</script>';
                echo '<script>window.location="index.php"</script>';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
<!-- site metas -->
<title>PCDEAL</title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content="">
<!-- bootstrap css -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- style css -->
<link rel="stylesheet" href="css/style.css">
<!-- Responsive-->
<link rel="stylesheet" href="css/responsive.css">
<!-- fevicon -->
<link rel="icon" href="C:\Users\ASUS\Desktop\Suivi 1\ASSETS\image\fevicon.png" type="image/gif" />
<!-- Scrollbar Custom CSS -->
<link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
<!-- Tweaks for older IEs-->
<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
<!-- owl stylesheets -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
</head>

<body class="main-layout">

    <div class="loader_bg">
        <div class="loader"><img src="ASSETS/image/loading.gif" alt="#" /></div>
    </div>


    <header>

        <div class="header">

            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                        <div class="full">
                            <div class="center-desk">
                                <div class="logo">
                                    <a href="forum.html"><img src="ASSETS/image/logo.png" height="75" width="150" alt="#"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                        <div class="menu-area">
                            <div class="limit-box">
                                <nav class="main-menu">
                                    <ul class="menu-area-main">
                                        <li class="active"> <a href="index.html">Home</a> </li>
                                        <li> <a href="about.html">About</a> </li>
                                        <li><a href="brand.html">Brand</a></li>
                                        <li><a href="special.html">Specials</a></li>
                                        <li><a href="forum.html">Forum</a></li>
                                        <li><a href="contact.html">Contact Us</a></li>
                                        <li class="last">
                                            <a href="#"><img src="ASSETS/image/search_icon.png" alt="icon" /></a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>

    </header>






    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Shopping Cart</title>

        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous">
        </script>

        <style>
            @import url('https://fonts.googleapis.com/css?family=Titillium+Web');

            * {
                font-family: 'Titillium Web', sans-serif;
            }

            .product {
                border: 1px solid #eaeaec;
                margin: -1px 19px 3px -1px;
                padding: 10px;
                text-align: center;
                background-color: #efefef;
            }

            table,
            th,
            tr {
                text-align: center;
            }

            .stripe-button {
                -moz-box-shadow: 3px 4px 0px 0px #1564ad;
                -webkit-box-shadow: 3px 4px 0px 0px #1564ad;
                box-shadow: 3px 4px 0px 0px #1564ad;
                background: -webkit-gradient(linear, left top, left bottom, color-stop(0.05, #79bbff), color-stop(1, #378de5));
                background: -moz-linear-gradient(top, #79bbff 5%, #378de5 100%);
                background: -webkit-linear-gradient(top, #79bbff 5%, #378de5 100%);
                background: -o-linear-gradient(top, #79bbff 5%, #378de5 100%);
                background: -ms-linear-gradient(top, #79bbff 5%, #378de5 100%);
                background: linear-gradient(to bottom, #79bbff 5%, #378de5 100%);
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#79bbff', endColorstr='#378de5', GradientType=0);
                background-color: #79bbff;
                -moz-border-radius: 5px;
                -webkit-border-radius: 5px;
                border-radius: 5px;
                border: 1px solid #337bc4;
                display: inline-block;
                cursor: pointer;
                color: #ffffff;
                font-family: Arial;
                font-size: 17px;
                font-weight: bold;
                padding: 12px 44px;
                text-decoration: none;
                text-shadow: 0px 1px 0px #528ecc;
            }


            .title2 {
                text-align: center;
                color: #66afe9;
                background-color: #efefef;
                padding: 2%;
            }

            h2 {
                text-align: center;
                color: #66afe9;
                background-color: #efefef;
                padding: 2%;
            }

            table th {
                background-color: #efefef;
            }
        </style>
    </head>

    <body>

        <div class="container" style="width: 65%">
            <h2>Shopping Cart</h2>
            <?php
            $query = "SELECT * FROM product ORDER BY id ASC ";
            $result = mysqli_query($con, $query);
            if (mysqli_num_rows($result) > 0) {

                while ($row = mysqli_fetch_array($result)) {

            ?>
                    <div class="col-md-3">

                        <form method="post" action="index.php?action=add&id=<?php echo $row["id"]; ?>">

                            <div class="product">
                                <img src="../back/images/<?php echo $row["image"]; ?>" class="img-responsive">
                                <h5 class="text-info"><?php echo $row["pname"]; ?></h5>
                                <h5 class="text-danger"><?php echo $row["price"]; ?></h5>
                                <input type="text" name="quantity" class="form-control" value="1">
                                <input type="hidden" name="hidden_name" value="<?php echo $row["pname"]; ?>">
                                <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                                <input type="submit" name="add" style="margin-top: 5px;" class="btn btn-success" value="Add to Cart">
                            </div>
                        </form>
                    </div>
            <?php
                }
            }
            ?>

            <div style="clear: both"></div>
            <h3 class="title2">Shopping Cart Details</h3>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <tr>
                        <th width="30%">Product Name</th>
                        <th width="10%">Quantity</th>
                        <th width="13%">Price Details</th>
                        <th width="10%">Total Price</th>
                        <th width="17%">Remove Item</th>
                    </tr>

                    <?php
                    if (!empty($_SESSION["cart"])) {
                        $total = 0;
                        foreach ($_SESSION["cart"] as $key => $value) {
                    ?>
                            <tr>
                                <td><?php echo $value["item_name"]; ?></td>
                                <td><?php echo $value["item_quantity"]; ?></td>
                                <td>$ <?php echo $value["product_price"]; ?></td>
                                <td>
                                    $ <?php echo number_format($value["item_quantity"] * $value["product_price"], 2); ?></td>
                                <td><a href="index.php?action=delete&id=<?php echo $value["product_id"]; ?>"><span class="text-danger">Remove Item</span></a></td>

                            </tr>
                        <?php
                            $total = $total + ($value["item_quantity"] * $value["product_price"]);
                        }
                        ?>
                        <tr>
                            <td colspan="3" align="right">Total</td>
                            <th align="right">$ <?php echo number_format($total, 2); ?></th>
                            <td></td>
                        </tr>
                    <?php
                    }
                    ?>
                    <?php

                    // Product Details  
                    // Minimum amount is $0.50 US  
                    $productName = "payment";
                    $productID = "DP12345";
                    $productPrice = $total;
                    $currency = "usd";
                    ?>
                </table>
                <!-- Display errors returned by checkout session -->
                <div id="paymentResponse" class="hidden"></div>

                <!-- Product details -->
                <h2><?php echo $productName; ?></h2>


                <p>Price: <b>$<?php echo $productPrice . ' ' . strtoupper($currency); ?></b></p>

                <!-- Payment button -->
                

            </div>
            <form action="mail.php" method="post">

                        
                <button class="stripe-button"  id="payButton">
                   Pay Now
                </button>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" name="emailaddress" aria-describedby="emailHelp" placeholder="Enter email">
                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>
                <div class="form-group">
                    <label for="exampleInputnom">name</label>
                    <input type="text" name="name" class="form-control" id="exampleInputnom" placeholder="nom">
                </div>
                <div class="form-group">
                    <label for="exampleInputmobile">mobile</label>
                    <input type="text" class="form-control" name="mobile" id="exampleInputmobile" placeholder="nom">
                </div>
                <div class="form-group">
                    <label for="exampleInputmsg">Message</label>
                    <input type="text" class="form-control" name="message" id="exampleInputmsg" placeholder="nom">
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>


    </body>

</html>

<!--HOUNI THOT KHEDMTEK LKOOOOOOOL-->

<footer>
    <div id="contact" class="footer">
        <div class="container">
            <div class="row pdn-top-30">
                <div class="col-md-12 ">
                    <div class="footer-box">
                        <div class="headinga">
                            <h3>Address</h3>
                            <span>Berges du Lac Mariout BHB 110711, P.O. Box 2045, Tunis, Tunisia</span>
                            <p>(+216) 71 961 983 / 4 (+216) 71 961 985
                                <br>datalords@gmail.com
                            </p>
                        </div>
                        <ul class="location_icon">
                            <li> <a href="#"><i class="fa fa-facebook-f"></i></a></li>
                            <li> <a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li> <a href="#"><i class="fa fa-instagram"></i></a></li>

                        </ul>
                        <div class="menu-bottom">
                            <ul class="link">
                                <li> <a href="#">Home</a></li>
                                <li> <a href="#">About</a></li>
                                <li> <a href="#">Forum</a></li>
                                <li> <a href="#">Brand </a></li>
                                <li> <a href="#">Specials </a></li>
                                <li> <a href="#"> Contact us</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright">
            <div class="container">
                <p>PCDEAL© 2021 All Rights Reserved. Design By DATALORDS</p>
            </div>
        </div>
    </div>
</footer>
<!-- end footer -->
<!-- Javascript files-->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
<!-- javascript -->
<script src="js/owl.carousel.js"></script>
<!-- Stripe JavaScript library -->
<script src="https://js.stripe.com/v3/"></script>

<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
<script>
    $(document).ready(function() {
        $(".fancybox").fancybox({
            openEffect: "none",
            closeEffect: "none"
        });

        $(".zoom").hover(function() {

            $(this).addClass('transition');
        }, function() {

            $(this).removeClass('transition');
        });
    });
</script>
<script>
    // Set Stripe publishable key to initialize Stripe.js
    const stripe = Stripe('<?php echo STRIPE_PUBLISHABLE_KEY; ?>');

    // Select payment button
    const payBtn = document.querySelector("#payButton");

    // Payment request handler
    payBtn.addEventListener("click", function(evt) {
        setLoading(true);

        createCheckoutSession().then(function(data) {
            if (data.sessionId) {
                stripe.redirectToCheckout({
                    sessionId: data.sessionId,
                }).then(handleResult);
            } else {
                handleResult(data);
            }
        });
    });

    // Create a Checkout Session with the selected product
    const createCheckoutSession = function(stripe) {
        return fetch("payment_init.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                createCheckoutSession: 1,
            }),
        }).then(function(result) {
            return result.json();
        });
    };

    // Handle any errors returned from Checkout
    const handleResult = function(result) {
        if (result.error) {
            showMessage(result.error.message);
        }

        setLoading(false);
    };

    // Show a spinner on payment processing
    function setLoading(isLoading) {
        if (isLoading) {
            // Disable the button and show a spinner
            payBtn.disabled = true;
            document.querySelector("#spinner").classList.remove("hidden");
            document.querySelector("#buttonText").classList.add("hidden");
        } else {
            // Enable the button and hide spinner
            payBtn.disabled = false;
            document.querySelector("#spinner").classList.add("hidden");
            document.querySelector("#buttonText").classList.remove("hidden");
        }
    }

    // Display message
    function showMessage(messageText) {
        const messageContainer = document.querySelector("#paymentResponse");

        messageContainer.classList.remove("hidden");
        messageContainer.textContent = messageText;

        setTimeout(function() {
            messageContainer.classList.add("hidden");
            messageText.textContent = "";
        }, 5000);
    }
</script>



</body>

</html>