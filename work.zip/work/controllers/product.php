<?php
class client
{
    private $id;
	private $pname;
	private $image;
	private $price;
  
	function __construct($id,$pname,$image,$price)
	{
       
        $this->id=$id; 
		$this->pname=$pname;
        $this->image=$image;
        $this->price=$price;
       
	}
    function getid()
    {
        return $this->id;
    }
	function getpname()
    {
        return $this->pname;
    }
    function getimage()
    {
        return $this->image;
    }
    function getprice()
    {
        return $this->price;
    }
    
    function setid($id)
    {
        $this->id = $id;
    }
     function setpname($pname)
    {
        $this->pname = $pname;
    }
     function setimage($image)
    {
        $this->image = $image;
    }
     function setprice($price)
    {
        $this->price = $price;
    }
    
}
?>