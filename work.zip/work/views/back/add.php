<?php

include('db.php');

if(isset($_POST['submit'])){
	$id = $_POST['id'];
	$pname = $_POST['pname'];
	$image = $_POST['image'];
	$price = $_POST['price'];
	//image upload

	$msg = "";
	$image = $_FILES['image']['name'];
	$target = "images/".basename($image);

	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}

  	$insert_data = "INSERT INTO product (id,pname,image,price) VALUES ('$id','$pname','$image','$price')";
  	$run_data = mysqli_query($con,$insert_data);

  	if($run_data){
  		header('location:index.php');
  	}else{
  		echo "Data not insert";
  	}

}

?>