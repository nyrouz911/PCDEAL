<!DOCTYPE html>
<html lang="en-US">
<head>
<title>Payment Cancel</title>
<meta charset="utf-8">

<!-- Stylesheet file -->
<link href="css/style.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="status">
        <h1 class="error">Your transaction was canceled!</h1>
    </div>
    <a href="index.php" class="btn-link">Back to Product Page</a>
</div>
</body>
</html>