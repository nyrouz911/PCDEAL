<?php
include ("C:/xampp/htdocs/work/config.php");
include ("C:/xampp/htdocs/work/controllers/product.php");
class productC
{
   
	function ajoutproduit($product)
	{
       $sql = "INSERT INTO product (id,pname,image,price) values (:id,:pname,:image,:price)";//requete sql
       
        $db=config::getConnexion();
        try {
            
            $id=$product->getid();
        	$pname=$product->getpname();
            $image=$product->getimage(); 
            $price=$product->getprice();
            $req = $db->prepare($sql);
            $req->bindValue(':id', $id);
            $req->bindValue(':pname', $pname);
            $req->bindValue(':image', $image);
            $req->bindValue(':price', $price);
            
            
            
            $req->execute();
        } catch (Exception $e) {
            echo 'erreur: ' . $e->getMessage();
        }
	}
    function afficher_return()
        {
            $config=new config();
            $instance=$config->getConnexion();

           $response=$instance->query('SELECT * FROM product');
            return $response;
        }
}

?>