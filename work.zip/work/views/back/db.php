<?php
$con = mysqli_connect('localhost','root','','productdb');
if($con){
	
}else{
	echo "Not Connected";
}

?>